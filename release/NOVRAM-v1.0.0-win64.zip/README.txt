﻿NOVRAM v1.0.0

1. Close eFootball.
2. Run "NOVRAM Patcher.exe".
3. The patcher creates a backup before modifying eFootball.exe.

Supported/tested build: eFootball 6.1.0.0 (Steam/Windows)
Project: https://github.com/bulatakk/novram-efootball

NOVRAM does not add VRAM or change gameplay. It only bypasses the recurring GPU: VRAM 4GB startup warning on supported builds.
